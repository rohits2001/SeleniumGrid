package pages;

import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import base.BaseTest;

public class MenuTabPage extends BaseTest {

    WebElement btn_close;
    WebElement btn_adv;
    WebElement btn_menu;
    WebElement oil_Change;
    WebElement Auto_Repair;
    WebElement Car_Wash;
    WebElement parking;
    WebElement bedding;
    WebElement furniture;
    WebElement lawn;
    WebElement kitchen;

    public MenuTabPage() {
        this.driver = driver;
        PageFactory.initElements(getDriver(), this);
    }

    public void btn_close() {
        System.out.println("Clicking on Close button...");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("btn_close")))).click();
    }

    public void btn_closeAD() {
        System.out.println("Clicking on Close Ad button...");
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("btn_adv")))).click();
    }

    public void hoverTab() throws InterruptedException {
        System.out.println("Hovering over the Menu Tab...");
        WebElement home = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("btn_menu"))));

        Actions actions = new Actions(getDriver());
        actions.moveToElement(home).perform();
        Thread.sleep(1000); // Giving some time for hover effect
    }

    public class ServiceElements {

        public String oil_change() {
            System.out.println("Verifying 'Oil Change' menu item...");
            return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("oil_Change")))).getText();
        }

        public String Auto_Repair() {
            System.out.println("Verifying 'Auto Repair' menu item...");
            return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("Auto_Repair")))).getText();
        }

        public String Car_Wash() {
            System.out.println("Verifying 'Car Wash' menu item...");
            return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("Car_Wash")))).getText();
        }

        public String parking() {
            System.out.println("Verifying 'Parking' menu item...");
            return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("parking")))).getText();
        }

        public String bedding() {
            System.out.println("Verifying 'Bedding' menu item...");
            return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("bedding")))).getText();
        }

        public String furniture() {
            System.out.println("Verifying 'Furniture' menu item...");
            return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("furniture")))).getText();
        }

        public String lawn() {
            System.out.println("Verifying 'Lawn' menu item...");
            return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("lawn")))).getText();
        }

        public String kitchen() {
            System.out.println("Verifying 'Kitchen' menu item...");
            return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("kitchen")))).getText();
        }

        public String home() {
            System.out.println("Verifying 'Home' menu item...");
            return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("home")))).getText();
        }

        public String cleaning() {
            System.out.println("Verifying 'Cleaning' menu item...");
            return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("cleaning")))).getText();
        }
    }
}
