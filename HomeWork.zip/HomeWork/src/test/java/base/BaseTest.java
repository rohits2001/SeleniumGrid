package base;

import java.io.FileReader;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseTest {

    public static WebDriver driver;
    public static Properties prop = new Properties();
    public static Properties loc = new Properties();
    public static FileReader frprop;
    public static FileReader frloc;
    public static SoftAssert softAssert;
    public static WebDriverWait wait;
    public static ExtentReports extentReports;
    public static ExtentTest extentTest;
    public static ExtentSparkReporter sparkReporter;
    public static ThreadLocal<String> assertionMessage = new ThreadLocal<>();  // Initialize here

    @BeforeSuite
    public void setupReport() {
        sparkReporter = new ExtentSparkReporter("extent-report.html");
        extentReports = new ExtentReports();
        extentReports.attachReporter(sparkReporter);

        sparkReporter.config().setDocumentTitle("Test Report");
        sparkReporter.config().setReportName("Selenium Test Report");
    }

    @Parameters("browser")
    @BeforeMethod
    public void setup(String browser) throws IOException {
        if (driver == null) {

            frprop = new FileReader(
                    System.getProperty("user.dir") + "\\src\\test\\resources\\configFiles\\config.properties");
            prop.load(frprop);

            frloc = new FileReader(
                    System.getProperty("user.dir") + "\\src\\test\\resources\\configFiles\\locators.properties");
            loc.load(frloc);

            softAssert = new SoftAssert();
        }

        if (browser.equalsIgnoreCase("chrome")) {
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();
        } else if (browser.equalsIgnoreCase("firefox")) {
            WebDriverManager.firefoxdriver().setup();
            driver = new FirefoxDriver();
        } else if (browser.equalsIgnoreCase("edge")) {
            WebDriverManager.edgedriver().setup();
            driver = new EdgeDriver();
        }

        driver.manage().window().maximize();
        driver.get(prop.getProperty("testURL"));
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
    }

    public static WebDriver getDriver() {
        return driver;
    }

    public static String getAssertionMessage() {
        return assertionMessage.get();
    }

    @AfterMethod
    public void tearDown() throws InterruptedException {
        if (driver != null) {
            driver.quit();
        }
    }

    @AfterSuite
    public void tearDownReport() {
        extentReports.flush();
    }

    public static void logExceptionToReport(Exception e) {
        extentTest.log(Status.FAIL, "Exception occurred: " + e.getMessage());
        for (StackTraceElement element : e.getStackTrace()) {
            extentTest.log(Status.FAIL, element.toString());
        }
    }
}
