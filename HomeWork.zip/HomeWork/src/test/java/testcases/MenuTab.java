package testcases;

import java.io.IOException;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import base.BaseTest;
import pages.MenuTabPage;
import utilities.ReadXLData;

public class MenuTab extends BaseTest {

    MenuTabPage tab; // Instance of MenuTabPage
    SoftAssert softAssert;  // Declare the SoftAssert variable

    @Test(dataProviderClass = ReadXLData.class, dataProvider = "testData")
    public void datasheet(String[] submenu) throws InterruptedException, IOException {

        // Initialize SoftAssert
        softAssert = new SoftAssert();
        assertionMessage = new ThreadLocal<>();  // Initialize assertionMessage

        // Initialize MenuTabPage
        tab = new MenuTabPage();

        // Close buttons
        tab.btn_close();
        tab.btn_closeAD();

        // Hover over the menu
        tab.hoverTab();

        // Access and validate service elements
        MenuTabPage.ServiceElements serviceElements = tab.new ServiceElements();
        
        System.out.println("Validating service elements...");

        softAssert.assertEquals(serviceElements.oil_change(), submenu[0], "Oil change text mismatch");
        softAssert.assertEquals(serviceElements.Auto_Repair(), submenu[1], "Auto repair text mismatch");
        softAssert.assertEquals(serviceElements.bedding(), submenu[2], "Bedding text mismatch");
        softAssert.assertEquals(serviceElements.Car_Wash(), submenu[3], "Car wash text mismatch");
        softAssert.assertEquals(serviceElements.cleaning(), submenu[4], "Cleaning text mismatch");
        softAssert.assertEquals(serviceElements.furniture(), submenu[5], "Furniture text mismatch");
        softAssert.assertEquals(serviceElements.home(), submenu[6], "Home text mismatch");
        softAssert.assertEquals(serviceElements.parking(), submenu[7], "Parking text mismatch");
        softAssert.assertEquals(serviceElements.kitchen(), submenu[8], "Kitchen text mismatch");
        softAssert.assertEquals(serviceElements.lawn(), submenu[9], "Lawn text mismatch");

        // Collect assertions and handle any errors
        try {
            softAssert.assertAll();
        } catch (AssertionError e) {
            assertionMessage.set(e.getMessage());
            throw e;
        } catch (Exception e) {
            BaseTest.logExceptionToReport(e); // Log exception to Extent Reports
            throw e;
        }
    }
}
