package base;

import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.time.Duration;
import java.util.Properties;
import java.util.Set;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class BaseTest {

    protected static ThreadLocal<WebDriver> driver = new ThreadLocal<>();
    public static Properties prop = new Properties();
    public static Properties loc = new Properties();
    public static FileReader frprop;
    public static FileReader frloc;
    public static SoftAssert softAssert;
    public static WebDriverWait wait;
    public static ExtentReports extentReports;
    public static ExtentTest extentTest;
    public static ExtentSparkReporter sparkReporter;
    public static ThreadLocal<String> assertionMessage;

    @BeforeSuite
    public void setupReport() {
        sparkReporter = new ExtentSparkReporter("extent-report.html");
        extentReports = new ExtentReports();
        extentReports.attachReporter(sparkReporter);

        sparkReporter.config().setDocumentTitle("Test Report");
        sparkReporter.config().setReportName("Selenium Test Report");
    }

    @Parameters("browser")
    @BeforeTest
    public void setup(String browser) throws IOException {
        if (driver.get() == null) {
            frprop = new FileReader(
                    System.getProperty("user.dir") + "\\src\\test\\resources\\configFiles\\config.properties");
            prop.load(frprop);

            frloc = new FileReader(
                    System.getProperty("user.dir") + "\\src\\test\\resources\\configFiles\\locators.properties");
            loc.load(frloc);

            assertionMessage = new ThreadLocal<>();
        }

        DesiredCapabilities capabilities = new DesiredCapabilities();

        if (browser.equalsIgnoreCase("chrome")) {
            capabilities.setBrowserName("chrome");
        } else if (browser.equalsIgnoreCase("firefox")) {
            capabilities.setBrowserName("firefox");
        }

        driver.set(new RemoteWebDriver(new URL("http://localhost:4444/wd/hub"), capabilities));
        getDriver().manage().window().maximize();
        getDriver().get(prop.getProperty("testURL"));
        wait = new WebDriverWait(getDriver(), Duration.ofSeconds(20));
    }

    public static WebDriver getDriver() {
        return driver.get();
    }

    public static String getAssertionMessage() {
        return assertionMessage.get();
    }

    public static void scrollPageDown() {
        Actions action = new Actions(getDriver());
        action.sendKeys(Keys.PAGE_DOWN).build().perform();
    }

    public static void switchToNewTab() {
        String originalWindow = getDriver().getWindowHandle();
        Set<String> allWindows = getDriver().getWindowHandles();
        for (String windowHandle : allWindows) {
            if (!windowHandle.equals(originalWindow)) {
                getDriver().switchTo().window(windowHandle);
                break;
            }
        }
    }

    @AfterTest
    public void tearDown() throws InterruptedException {
        if (getDriver() != null) {
            getDriver().close();
            driver.remove(); // Properly remove the ThreadLocal instance
        }
    }

    @AfterSuite
    public void tearDownReport() {
        extentReports.flush();
    }

    public static void logExceptionToReport(Exception e) {
        extentTest.log(Status.FAIL, "Exception occurred: " + e.getMessage());
        for (StackTraceElement element : e.getStackTrace()) {
            extentTest.log(Status.FAIL, element.toString());
        }
    }
}
